export { default as Tick } from "./tick.astro";
